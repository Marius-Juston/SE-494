Tasks to be completed:

Python:

1. Connect python interface with SQL server
2. Create the joins statements for the insert query for the databse
3. Create a UI where the user can input:
    1. operator name (string)
    2. shope floor order number (8 digit number)
    3. line number
    4. save button (trigger sql server saving )
4. Keyene integration:
   1. Wait for the order number to be inputed
   2. Change the keyence configuration to reflect the new specifications
   3. Either:
      1. Cotinously update the spec graph and save the stataic slice once the save button is pressed
      2. Only take a single input once the save button is pressed

Network config:

1. Open terminal on machine
2. `ipconfig` get the ip address of the network address
3. Copy IPv4 XXX.XXX.XXX.AAA replace AAA with unique number
4. Copy Network mask
5. Got to output settings
    1. Turn on non-procedural settings
    2. Toggle ethernet
    3. Add all outputs, set outputs to comma seperated
   4. Go to network settings
      1. Change IP address
      2. Change network mask

TeraTerm:
1. New Connection
2. Host XXX.XXX.XXX.AAA
3. Service: Other
4. TCP Port 8600